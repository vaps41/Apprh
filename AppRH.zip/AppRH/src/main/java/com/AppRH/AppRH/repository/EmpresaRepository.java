package com.AppRH.AppRH.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.AppRH.AppRH.models.Empresa;
@Repository
public interface EmpresaRepository extends CrudRepository<Empresa, Long> {
	
	Empresa findById(long id);
	Empresa findByNomeEmpresa(String nomeEmpresa);
	
	// Query para a busca
	@Query(value = "select u from Empresa u where u.nomeEmpresa like %?1%")
	List<Empresa> findByNomes(String nomeEmpresa);
}
